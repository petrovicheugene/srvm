#ifndef ZPLOTTERDEFAULVARIABLES
#define ZPLOTTERDEFAULVARIABLES

extern const qreal gl_defaultSpectrumZValue;
extern const qreal gl_currentSpectrumZValue;
extern const qreal gl_defaultWindowZValue;
extern const qreal gl_currentWindowZValue;

#endif // ZPLOTTERDEFAULVARIABLES

