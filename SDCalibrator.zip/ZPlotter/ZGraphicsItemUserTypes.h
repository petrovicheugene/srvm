#ifndef ZGRAPHICSITEMUSERTYPES
#define ZGRAPHICSITEMUSERTYPES
#include <QGraphicsItem>
const int SpectrumItemType = QGraphicsItem::UserType + 1;
const int WindowItemType = QGraphicsItem::UserType + 2;
const int DefaultRectItemType = QGraphicsItem::UserType + 3;

#endif // ZGRAPHICSITEMUSERTYPES

